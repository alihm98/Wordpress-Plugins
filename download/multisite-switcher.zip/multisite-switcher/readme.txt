=== Multisite Switcher ===
Contributors: cedbv
Donate link: http://www.boverie.eu/
Tags: multisite,switch,administration,admin
Requires at least: 3.0
Tested up to: 3.0
Stable tag: 1.0

In a multisite configuration, add a dropdown menu in administration to let you switch between sites admin.

== Description ==

Don't Work in Wordpress MU. Wordpress 3 only.
Usefull only if you have a multisite install and if some users manages more than one blog.

This plugin adds a simple dropdown menu in administration header that allows you (and every site users) to switch 
between administration of every site they are member of (and so work for super-admin, admin, contributors,...).

Work best if the plugin is **Network Activate**.

== Installation ==

1. Upload `multisite-switcher` directory to the `/wp-content/plugins/` directory.
2. Activate (or Network Activate) the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

= What are the requirements ? =
* Wordpress 3.0
* a multisite installation

== Screenshots ==

1. dropdown menu

== Changelog ==

= 1.0 =
* First public version.

== Upgrade Notice ==

= 1.0 =
Is it possible to upgrade to the first version ?