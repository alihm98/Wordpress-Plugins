<?php
// Traduction de la description
__('Display asides in a widget. They can automatically be published to Twitter, Facebook, and any Status.net installation (like identi.ca).');