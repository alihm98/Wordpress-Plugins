=== Skyrock Blog Importer ===
Contributors: cedbv
Donate link: http://www.boverie.eu/anothertime/
Tags: importer,skyrock
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: 0.2

Import posts, tags, comments, images and videos from a Skyrock Blog (a french blog platform).

== Description ==

The Skyrock Blog will import the following content from an online Skyrock Blog :

* Posts
* Tags
* Comments
* Small definition images
* Videos and some gadgets

== Installation ==

1. Upload `skyrock-blog-importer` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to the Tools -> Import screen, click on 'Skyrock Blog' and follow the instructions.

== Changelog ==

= 0.2 =
* Update to support new version of Skyrock
* Import of tags

= 0.1 =
* Initial release

== Upgrade Notice ==

= 0.2 =
Importation of tags and update to follow Skyrock changes